
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
app.use(bodyParser.json());
app.use(express.static('public'));

function loadDB(){
  return JSON.parse(fs.readFileSync('db.json','utf8'));
}
function saveDB(db){
  fs.writeFileSync('db.json', JSON.stringify(db,null,2));
}

// password
app.post('/api/password/create',(req,res)=>{
  const {password}=req.body;
  const db=loadDB();
  if(db.password) return res.json({ok:false,msg:"Password exists"});
  db.password=password;
  saveDB(db);
  res.json({ok:true});
});
app.post('/api/password/confirm',(req,res)=>{
  const {password}=req.body;
  const db=loadDB();
  res.json({ok: db.password===password});
});
app.post('/api/password/reset',(req,res)=>{
  const db=loadDB(); db.password=null; saveDB(db);
  res.json({ok:true});
});

// wallet
app.post('/api/wallet/bind',(req,res)=>{
  const {address}=req.body;
  const db=loadDB();
  if(db.wallet) return res.json({ok:false,msg:"Wallet exists"});
  db.wallet=address; saveDB(db);
  res.json({ok:true});
});
app.post('/api/wallet/modify',(req,res)=>{
  const {address}=req.body;
  const db=loadDB();
  db.wallet=address; saveDB(db);
  res.json({ok:true});
});

// withdraw
const { sendWithdrawNotification } = require('./bot');

app.post('/api/withdraw/submit', async (req,res)=>{
  const {amount,password}=req.body;
  const db=loadDB();
  if(db.password!==password) return res.json({ok:false,msg:"Bad password"});
  if(!db.wallet) return res.json({ok:false,msg:"No wallet"});
  const record={amount, wallet:db.wallet, time:Date.now()};
  db.withdrawals.push(record);
  saveDB(db);

  await sendWithdrawNotification(record);
  res.json({ok:true});
});

const PORT=process.env.PORT||3000;
app.listen(PORT, ()=>console.log("Server on "+PORT));
