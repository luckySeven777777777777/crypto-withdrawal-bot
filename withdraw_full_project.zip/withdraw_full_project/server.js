const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
app.use(bodyParser.json());
app.use(express.static("public"));

// ====== 内存模拟数据库（可换成 MongoDB / PostgreSQL）======
let USER_WALLET = null;
let WITHDRAW_PASSWORD = null;

// ============ 获取钱包地址 ============
app.get("/api/wallet", (req, res) => {
    res.json({
        wallet: USER_WALLET
    });
});

// ============ 绑定 / 修改 钱包 ============
app.post("/api/wallet", (req, res) => {
    const { wallet, oldWallet } = req.body;

    // 修改钱包
    if (oldWallet) {
        if (USER_WALLET !== oldWallet) {
            return res.json({ success: false, error: "Old wallet incorrect" });
        }
        USER_WALLET = wallet;
        return res.json({ success: true, wallet });
    }

    // 绑定钱包
    if (!USER_WALLET) {
        USER_WALLET = wallet;
        return res.json({ success: true, wallet });
    }

    return res.json({ success: false, error: "Wallet already bound" });
});

// ============ 设置提现密码 ============
app.post("/api/password/set", (req, res) => {
    const { password } = req.body;
    WITHDRAW_PASSWORD = password;
    return res.json({ success: true });
});

// ============ 确认提现密码 ============
app.post("/api/password/confirm", (req, res) => {
    const { password } = req.body;
    if (password === WITHDRAW_PASSWORD) {
        return res.json({ success: true });
    }
    return res.json({ success: false, error: "Incorrect password" });
});

// ============ 提现 ============
app.post("/api/withdraw", (req, res) => {
    const { coin, amount, wallet, hash } = req.body;

    console.log("提现请求：", { coin, amount, wallet, hash });

    return res.json({
        success: true,
        txHash: hash
    });
});

// ============ Railway Health check ============
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public/index.html"));
});

// ============ 启动服务器 ============
const port = process.env.PORT || 3000;
app.listen(port, () => console.log("Server running on port " + port));
