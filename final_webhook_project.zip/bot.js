const { Telegraf } = require('telegraf');

const bot = new Telegraf(process.env.BOT_TOKEN);

// 提现通知函数
async function sendWithdrawNotification(record) {
  const chat_id = process.env.ADMIN_CHAT_ID;
  if (!chat_id) return;

  const msg = `用户提现申请:\n币种: ${record.coin}\n金额: ${record.amount}\n钱包: ${record.wallet}`;
  await bot.telegram.sendMessage(chat_id, msg);
}

module.exports = { bot, sendWithdrawNotification };
