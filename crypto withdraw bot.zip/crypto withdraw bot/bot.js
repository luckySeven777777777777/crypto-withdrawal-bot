const { Telegraf } = require('telegraf');
const fs = require('fs');
const path = require('path');

const bot = new Telegraf(process.env.BOT_TOKEN);
const DB_FILE = path.join(__dirname, 'db.json');

function loadDB() {
    if (!fs.existsSync(DB_FILE)) return {};
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}

function saveDB(db) {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
}

// Telegram 按钮回调
bot.on('callback_query', ctx => {
    const data = ctx.callbackQuery.data;
    const db = loadDB();

    if (data.startsWith('withdraw_')) {
        const [_, hash, action] = data.split('_'); // withdraw_hash_action
        if (!db.withdraws) db.withdraws = {};
        if (!db.withdraws[hash]) db.withdraws[hash] = {};
        db.withdraws[hash].status = action;
        saveDB(db);
        ctx.answerCbQuery(`提现已${action === 'success' ? '成功' : '取消'}`);
        ctx.reply(`提现 ${action === 'success' ? '成功 ✔' : '取消 ✖'} 已确认`);
    }
});

async function sendWithdrawNotification(record) {
    const chat_id = process.env.ADMIN_CHAT_ID;
    if (!chat_id) return;

    const msg = `💰 用户提现申请\n金额: ${record.amount}\n币种: ${record.coin}\n钱包: ${record.wallet}\n交易哈希: ${record.hash}`;
    await bot.telegram.sendMessage(chat_id, msg, {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: "✔ 成功", callback_data: `withdraw_${record.hash}_success` },
                    { text: "✖ 取消", callback_data: `withdraw_${record.hash}_cancel` }
                ]
            ]
        }
    });
}

bot.launch();

module.exports = { sendWithdrawNotification };
