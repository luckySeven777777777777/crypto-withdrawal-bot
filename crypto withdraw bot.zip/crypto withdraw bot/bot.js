const TelegramBot = require('node-telegram-bot-api');

const BOT_TOKEN = process.env.BOT_TOKEN;
const CHAT_ID = process.env.GROUP_ID;

if (!BOT_TOKEN || !CHAT_ID) {
  console.error("请在环境变量中设置 BOT_TOKEN 和 GROUP_ID");
  process.exit(1);
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function sendWithdrawalMessage(data) {
  const message = `📤 *NEW WITHDRAWAL REQUEST*\n--------------------------------
💰 Coin: ${data.coin}
🔢 Amount: ${data.amount}
💵 USDT: ${data.usdt.toFixed(4)}
🏦 Wallet: ${data.wallet}
🆔 Transaction Hash: ${data.hash}
⚠️ Wallet & password bound once.`;

  return bot.sendMessage(CHAT_ID, message, {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Success', callback_data: 'success' },
          { text: '❌ Cancel', callback_data: 'cancel' }
        ]
      ]
    }
  });
}

// 处理按钮点击
bot.on('callback_query', query => {
  if (query.data === 'success') {
    bot.sendMessage(CHAT_ID, `✅ Withdrawal marked as SUCCESS by ${query.from.first_name}`);
  } else if (query.data === 'cancel') {
    bot.sendMessage(CHAT_ID, `❌ Withdrawal marked as CANCELLED by ${query.from.first_name}`);
  }
  bot.answerCallbackQuery(query.id);
});

module.exports = { sendWithdrawalMessage };
