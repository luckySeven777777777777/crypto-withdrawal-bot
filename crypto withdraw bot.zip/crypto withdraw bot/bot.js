import fetch from 'node-fetch';
import dotenv from 'dotenv';
dotenv.config();

const BOT_TOKEN = process.env.BOT_TOKEN;
const GROUP_ID = process.env.GROUP_ID;

export async function sendWithdrawalMessage(payload){
    const text = `📤 *NEW WITHDRAWAL REQUEST*
--------------------------------
💰 Coin: ${payload.coin}
🔢 Amount: ${payload.amount}
💵 USDT: ${payload.usdt}
🏦 Wallet: ${payload.wallet}
🆔 Transaction Hash: ${payload.hash}`;

    const reply_markup = {
        inline_keyboard: [
            [
                { text: "✅ Success", callback_data: "success" },
                { text: "❌ Cancel", callback_data: "cancel" }
            ]
        ]
    };

    const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
    const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            chat_id: GROUP_ID,
            text,
            parse_mode: "Markdown",
            reply_markup
        })
    });

    return res.json();
}
