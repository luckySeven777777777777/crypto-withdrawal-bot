import { Telegraf } from "telegraf";
import fetch from "node-fetch";

export function botInit(withdrawals) {
  const BOT_TOKEN = "8228143745:AAG1C6r7-8vwR4ajw4M-__FF1N9DoLdUQx0";
  const GROUP_ID = "-1003122480155";

  const bot = new Telegraf(BOT_TOKEN);

  bot.start((ctx) => ctx.reply("Bot is running"));

  // 发送提现通知（前端可以用fetch调用后端API或直接Telegram API）
  bot.sendWithdrawal = async (message, txHash) => {
    await bot.telegram.sendMessage(GROUP_ID, message, {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "✔ 成功交易", callback_data: `success_${txHash}` },
            { text: "✖ 取消交易", callback_data: `cancel_${txHash}` }
          ]
        ]
      }
    });
  };

  bot.on("callback_query", async (ctx) => {
    const data = ctx.callbackQuery.data;
    const [action, txHash] = data.split("_");

    if (!withdrawals[txHash] || withdrawals[txHash] === "pending") {
      const status = action === "success" ? "success" : "cancel";
      withdrawals[txHash] = status;

      // 调用后端API更新状态
      await fetch(`${process.env.SERVER_URL || "http://localhost:3000"}/api/update-status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ txHash, status })
      });

      await ctx.answerCbQuery(`已标记: ${status}`);
      await ctx.editMessageReplyMarkup(); // 移除按钮
    } else {
      await ctx.answerCbQuery("已操作过，不能重复点击", { show_alert: true });
    }
  });

  bot.launch();
  console.log("Telegram Bot launched");
}
