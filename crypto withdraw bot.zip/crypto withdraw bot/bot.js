// bot.js
import fetch from "node-fetch";

// 读取环境变量（在 Railway 上设置）
const BOT_TOKEN = process.env.BOT_TOKEN;
const GROUP_ID = process.env.GROUP_ID;

/**
 * 发送提现消息到 Telegram 群
 * @param {Object} data 提现信息
 * data = {
 *   coin: "BTC",
 *   amount: 1.23,
 *   usdt: 30000,
 *   wallet: "0x123abc...",
 *   password: "******",
 *   txHash: "TX-abc123"
 * }
 */
export async function sendWithdrawalMessage(data) {
  const message = `
📤 *NEW WITHDRAWAL REQUEST*
--------------------------------
💰 Coin: ${data.coin}
🔢 Amount: ${data.amount}
💵 USDT: ${data.usdt.toFixed(4)}
🏦 Wallet: ${data.wallet}
🔐 Password: ${data.password}
🆔 Transaction Hash: ${data.txHash}
⚠️ Wallet & password can be bound once.
*Please screenshot the transaction hash for record.*
`;

  try {
    const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: GROUP_ID,
        text: message,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✔ 成功交易", callback_data: `success_${data.txHash}` },
              { text: "✖ 取消交易", callback_data: `cancel_${data.txHash}` }
            ]
          ]
        }
      })
    });

    const result = await res.json();
    if (!result.ok) {
      console.error("Telegram API Error:", result);
      return null;
    }
    return result.result; // 返回 Telegram 消息对象
  } catch (err) {
    console.error("Error sending Telegram message:", err);
    return null;
  }
}

/**
 * 处理 Telegram 回调（inline button 点击事件）
 * @param {Object} callbackQuery Telegram 回调数据
 * @returns {Promise<void>}
 */
export async function handleCallback(callbackQuery) {
  const callbackId = callbackQuery.id;
  const user = callbackQuery.from.username || callbackQuery.from.first_name;
  const data = callbackQuery.data; // 格式: success_TX-abc123 或 cancel_TX-abc123

  let text = "";
  if (data.startsWith("success_")) {
    text = `✅ 提现已标记为成功\n操作人: ${user}\nTransaction: ${data.replace("success_", "")}`;
  } else if (data.startsWith("cancel_")) {
    text = `❌ 提现已取消\n操作人: ${user}\nTransaction: ${data.replace("cancel_", "")}`;
  }

  // 回复用户（Telegram 让按钮只能点击一次）
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/answerCallbackQuery`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      callback_query_id: callbackId,
      text: "操作已记录 ✅",
      show_alert: false
    })
  });

  // 更新原消息，禁用按钮
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/editMessageReplyMarkup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: { inline_keyboard: [] }
    })
  });

  console.log("Callback handled:", text);
}
