import express from 'express';
import path from 'path';
import bodyParser from 'body-parser';
import { sendWithdrawalMessage } from './bot.js';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(bodyParser.json());

let userWallet = null;

// API 路由必须放在静态文件之前

// 获取钱包
app.get('/api/wallet', (req,res)=>{
    res.json({ wallet: userWallet || null });
});

// 绑定/修改钱包
app.post('/api/wallet', (req,res)=>{
    const { wallet, oldWallet } = req.body;
    if(userWallet){
        if(oldWallet !== userWallet){
            return res.status(400).json({ success:false, error:'旧钱包地址不正确' });
        }
    }
    userWallet = wallet;
    res.json({ success:true, wallet:userWallet });
});

// 提现
app.post('/api/withdraw', async (req,res)=>{
    const { coin, amount, usdt, wallet, hash } = req.body;
    if(!coin || !amount || !usdt || !wallet || !hash){
        return res.status(400).json({ success:false, error:'Missing params' });
    }
    try{
        await sendWithdrawalMessage({ coin, amount, usdt, wallet, hash });
        res.json({ success:true });
    }catch(err){
        console.error(err);
        res.status(500).json({ success:false, error:'Telegram error' });
    }
});

// 静态文件
app.use(express.static(path.join(__dirname,'public')));

// 兜底路由
app.get('*', (req,res)=>{
    res.sendFile(path.join(__dirname,'public','index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log(`Server running on port ${PORT}`));
