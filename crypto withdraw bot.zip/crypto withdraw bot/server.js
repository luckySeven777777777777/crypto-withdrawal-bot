import express from "express";
import bodyParser from "body-parser";
import path from "path";
import { fileURLToPath } from "url";
import cors from "cors";
import { botInit } from "./bot.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

let withdrawals = {}; // 保存每笔提现状态

// API: 获取提现状态
app.get("/api/status/:txHash", (req, res) => {
  const { txHash } = req.params;
  res.json({ status: withdrawals[txHash] || "pending" });
});

// API: Bot回调更新提现状态
app.post("/api/update-status", (req, res) => {
  const { txHash, status } = req.body;
  if (!txHash || !status) return res.status(400).json({ error: "Missing txHash or status" });
  withdrawals[txHash] = status;
  res.json({ success: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

// 初始化 Telegram Bot
botInit(withdrawals);
