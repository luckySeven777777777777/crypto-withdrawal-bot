const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const { sendWithdrawalMessage } = require('./bot');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// 提交提现请求
app.post('/api/withdraw', async (req, res) => {
  try {
    const { coin, amount, usdt, wallet, hash } = req.body;
    await sendWithdrawalMessage({ coin, amount, usdt, wallet, hash });
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
