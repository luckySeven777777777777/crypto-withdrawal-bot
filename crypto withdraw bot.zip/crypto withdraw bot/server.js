const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { sendWithdrawalMessage } = require('./bot');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/api/withdraw', async (req, res) => {
  try {
    const { coin, amount, usdt, wallet, hash } = req.body;
    console.log('Withdrawal request received:', req.body);
    await sendWithdrawalMessage({ coin, amount, usdt, wallet, hash });
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
