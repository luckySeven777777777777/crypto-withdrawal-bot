
const express = require("express");
const path = require("path");
const cors = require("cors");
const { Telegraf } = require("telegraf");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

const BOT_TOKEN = process.env.BOT_TOKEN;
const ADMIN_CHAT_ID = process.env.ADMIN_CHAT_ID;
const WEBHOOK_URL = process.env.WEBHOOK_URL;

if (!WEBHOOK_URL) {
  console.warn("⚠️ WEBHOOK_URL not set. Bot webhook will not be registered until WEBHOOK_URL is set.");
}

let bot = null;
if (BOT_TOKEN) {
  try {
    bot = new Telegraf(BOT_TOKEN);
    // Basic handlers
    bot.start((ctx) => ctx.reply("🤖 Bot connected (webhook mode)."));
    bot.help((ctx) => ctx.reply("Send /start"));
    bot.on("text", (ctx) => ctx.reply("Received: " + ctx.message.text));
  } catch (e) {
    console.error("Failed to initialize Telegraf:", e);
    bot = null;
  }
} else {
  console.warn("⚠️ BOT_TOKEN not set. Telegram notifications will be disabled until BOT_TOKEN is configured.");
}

// In-memory simple wallet
let USER_WALLET = null;

// CORS preflight handled
app.options("*", (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  return res.sendStatus(200);
});

// GET wallet
app.get("/api/wallet", (req, res) => {
  res.json({ wallet: USER_WALLET });
});

// POST wallet (bind or update if oldWallet provided)
app.post("/api/wallet", (req, res) => {
  const { wallet, oldWallet } = req.body;
  if (!wallet) return res.status(400).json({ success: false, error: "Wallet required" });

  if (oldWallet) {
    if (USER_WALLET !== oldWallet) {
      return res.json({ success: false, error: "Old wallet incorrect" });
    }
    USER_WALLET = wallet;
    return res.json({ success: true, wallet: USER_WALLET });
  }

  if (!USER_WALLET) {
    USER_WALLET = wallet;
    return res.json({ success: true, wallet: USER_WALLET });
  }

  return res.json({ success: false, error: "Wallet already bound" });
});

// POST withdraw
app.post("/api/withdraw", async (req, res) => {
  const { coin, amount, wallet } = req.body;
  if (!coin || !amount || !wallet) return res.status(400).json({ success: false, error: "Missing params" });

  const hash = "TX-" + Date.now().toString(36) + "-" + Math.random().toString(36).substr(2, 8);

  // Send Telegram notification if bot is available
  if (bot && ADMIN_CHAT_ID) {
    try {
      await bot.telegram.sendMessage(
        ADMIN_CHAT_ID,
        `💸 Withdrawal Request\nCoin: ${coin}\nAmount: ${amount}\nWallet: ${wallet}\nTxHash: ${hash}`
      );
    } catch (err) {
      console.error("Failed to send Telegram message:", err);
    }
  }

  res.json({ success: true, hash });
});

// Static
const ROOT = path.resolve();
app.use(express.static(path.join(ROOT, "public")));

// If bot exists, register webhook and webhook callback route
if (bot) {
  if (WEBHOOK_URL) {
    // Register webhook (no top-level await)
    bot.telegram.setWebhook(`${WEBHOOK_URL}/telegraf`)
      .then(() => console.log("✅ Webhook set:", `${WEBHOOK_URL}/telegraf`))
      .catch((err) => console.error("❌ Failed to set webhook:", err));
    // Mount webhook callback
    app.use(bot.webhookCallback("/telegraf"));
  } else {
    console.warn("WEBHOOK_URL missing; bot webhook not set. Configure WEBHOOK_URL to enable.");
  }
}

// Fallback to index.html
app.get("*", (req, res) => {
  res.sendFile(path.join(ROOT, "public", "index.html"));
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Server running on port", PORT));
